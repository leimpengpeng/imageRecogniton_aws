TensorBoard is a suite of web applications for inspecting and understanding
your TensorFlow runs and graphs.


